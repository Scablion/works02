package ru.demo.tradeapp.repository;

import ru.demo.tradeapp.models.Unittype;

public class UnittypeDao extends BaseDao<Unittype> {
    public UnittypeDao() {
        super(Unittype.class);
    }
}
