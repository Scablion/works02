CREATE TABLE public.seasons (
  season_id SERIAL PRIMARY KEY,
  season_Name VARCHAR(50) NOT NULL,
  start_Date DATE NOT NULL,
  end_Date DATE NOT NULL
);

CREATE TABLE public.developers (
  developer_id SERIAL PRIMARY KEY,
  developer_Name VARCHAR(1000) NOT NULL,
  work_Begin_Date DATE NOT NULL
);

CREATE TABLE public.categories (
  category_id SERIAL PRIMARY KEY,
  category_Name VARCHAR(100) NOT NULL,
  parent_Category_id INT
);

CREATE TABLE public.goods (
  good_id SERIAL PRIMARY KEY,
  good_Name VARCHAR(200) NOT NULL,
  main_Photo BYTEA,
  second_Photo BYTEA,
  price FLOAT NOT NULL,
  weight FLOAT,
  width FLOAT,
  height FLOAT,
  length FLOAT,
  is_Active BOOLEAN NOT NULL,
  developer_id INT REFERENCES public.developers(developer_id),
  category_id INT REFERENCES public.categories(category_id)
);


CREATE TABLE public.season_Goods (
  season_Good_id SERIAL PRIMARY KEY,
  season_id INT REFERENCES public.seasons(season_id),
  good_id INT REFERENCES public.goods(good_id)
);


CREATE TABLE public.sells (
  sell_id SERIAL PRIMARY KEY,
  good_id INT REFERENCES public.goods(good_id),
  "count" INT NOT NULL,
  date_Sell TIMESTAMP NOT NULL
);


CREATE TABLE public.specialities (
  speciality_id SERIAL PRIMARY KEY,
  speciality_Name VARCHAR(50) NOT NULL,
  speciality_Pay FLOAT NOT NULL
);


CREATE TABLE public.services (
  service_id SERIAL PRIMARY KEY,
  service_Name VARCHAR(50) NOT NULL,
  service_Description VARCHAR(1000) NOT NULL,
  price FLOAT NOT NULL,
  time_Length INT NOT NULL,
  main_Photo BYTEA,
  second_Photo BYTEA
);


CREATE TABLE public.workers (
  worker_id SERIAL PRIMARY KEY,
  last_Name VARCHAR(50) NOT NULL,
  first_Name VARCHAR(50) NOT NULL,
  middle_Name VARCHAR(50),
  date_Of_Birth DATE NOT NULL,
  gender VARCHAR(10) NOT NULL,
  passport_Series VARCHAR(10) NOT NULL,
  passport_id VARCHAR(10) NOT NULL,
  passport_code VARCHAR(10) NOT NULL,
  is_Active BOOLEAN NOT NULL,
  pay_Coeff FLOAT NOT NULL,
  speciality_id INT REFERENCES public.specialities(speciality_id) ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE public.time_Sheets (
  time_Sheet_id SERIAL PRIMARY KEY,
  worker_id INT REFERENCES public.workers(worker_id),
  service_id INT REFERENCES public.services(service_id),
  service_Time TIME NOT NULL,
  gender_Check BOOLEAN NOT NULL
);


CREATE TABLE public.client_Types (
  client_Type_id SERIAL PRIMARY KEY,
  client_Type_name VARCHAR(50) NOT NULL,
  color VARCHAR(30) NOT NULL
);

CREATE TABLE public.clients (
  client_id SERIAL PRIMARY KEY,
  last_Name VARCHAR(50) NOT NULL,
  first_Name VARCHAR(50) NOT NULL,
  middle_Name VARCHAR(50),
  date_Of_Birth DATE NOT NULL,
  gender VARCHAR(10) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  email VARCHAR(200) NOT NULL,
  photo VARCHAR(100) NOT NULL,
  date_Of_Registration DATE NOT NULL,
  client_Type_id INT REFERENCES public.client_Types(client_Type_id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE public.visits (
  visit_id SERIAL PRIMARY KEY,
  client_id INT REFERENCES public.clients(client_id),
  time_Sheet_id INT REFERENCES public.time_Sheets(time_Sheet_id),
  date_Regs TIMESTAMP NOT NULL,
  date_Actual TIMESTAMP,
  paid BOOLEAN NOT NULL,
  rewiew VARCHAR(1000),
  document VARCHAR(1000)
);


CREATE TABLE public.sell_Visit (
  sell_Visit_id SERIAL PRIMARY KEY,
  sell_id INT REFERENCES public.sells(sell_id),
  visit_id INT REFERENCES public.visits(visit_id)
);


CREATE TABLE public.users (
  user_name VARCHAR(50) PRIMARY KEY,
  "password" VARCHAR(50) NOT NULL,
  role VARCHAR(10)
);


CREATE TABLE public.shares (
  share_id SERIAL PRIMARY KEY,
  share_Name VARCHAR(50) NOT NULL,
  share_Description VARCHAR(1000) NOT NULL
);


CREATE TABLE public.service_Shares (
  service_Share_id SERIAL PRIMARY KEY,
  share_id INT REFERENCES public.shares(share_id),
  service_id INT REFERENCES public.services(service_id)
);


CREATE TABLE public.complects (
  complect_id SERIAL PRIMARY KEY,
  main_Good_id INT REFERENCES public.goods(good_id),
  second_Good_id INT REFERENCES public.goods(good_id)
);


CREATE TABLE public.stores (
  store_id SERIAL PRIMARY KEY,
  good_id INT REFERENCES public.goods(good_id),
  "count" INT NOT NULL
);

-- Вставка данных в таблицу public.seasons
INSERT INTO public.seasons (season_Name, start_Date, end_Date) VALUES
('Весна', '2023-03-20', '2023-06-21'),
('Лето', '2023-06-22', '2023-09-22'),
('Осень', '2023-09-23', '2023-12-21'),
('Зима', '2023-12-22', '2024-03-19');

-- Вставка данных в таблицу public.developers
INSERT INTO public.developers (developer_Name, work_Begin_Date) VALUES
('Компания "А" ', '2022-01-01'),
('Компания "B" ', '2021-05-15');

-- Вставка данных в таблицу public.categories
INSERT INTO public.categories (category_Name, parent_Category_id) VALUES
('Одежда', NULL),
('Обувь', NULL),
('Аксессуары', NULL),
('Мужская одежда', 1),
('Женская одежда', 1),
('Детская одежда', 1),
('Спортивная одежда', 1),
('Кроссовки', 2),
('Туфли', 2),
('Ботинки', 2),
('Сумки', 3),
('Шляпы', 3),
('Очки', 3);


INSERT INTO public.goods (good_Name, main_Photo, second_Photo, price, weight, width, height, length, is_Active, developer_id, category_id) VALUES
  ('Футболка мужская', NULL, NULL, 15.99, 0.2, NULL, NULL, NULL, TRUE, 1, 4),
  ('Платье женское', NULL, NULL, 39.99, 0.3, NULL, NULL, NULL, TRUE, 2, 5),
  ('Куртка зимняя', NULL, NULL, 129.99, 1.2, NULL, NULL, NULL, TRUE, 1, 4),
  ('Кроссовки мужские', NULL, NULL, 59.99, 0.7, NULL, NULL, NULL, TRUE, 1, 8),
  ('Туфли женские', NULL, NULL, 49.99, 0.5, NULL, NULL, NULL, TRUE, 2, 9);

INSERT INTO public.season_Goods (season_id, good_id) VALUES
  (1, 1),
  (1, 2),
  (2, 3),
  (2, 4),
  (3, 5);

INSERT INTO public.sells (good_id, "count", date_Sell) VALUES
  (1, 5, '2023-04-10 12:30:00'),
  (2, 3, '2023-05-20 15:15:00'),
  (3, 2, '2023-06-15 10:45:00'),
  (4, 8, '2023-07-05 11:00:00'),
  (5, 1, '2023-08-10 16:30:00');

INSERT INTO public.specialities (speciality_Name, speciality_Pay) VALUES
  ('Парикмахер', 2500.00),
  ('Мастер маникюра', 2000.00),
  ('Косметолог', 3000.00);

INSERT INTO public.services (service_Name, service_Description, price, time_Length, main_Photo, second_Photo) VALUES
  ('Стрижка мужская', 'Классическая мужская стрижка', 25.00, 45, NULL, NULL),
  ('Стрижка женская', 'Классическая женская стрижка', 35.00, 60, NULL, NULL),
  ('Маникюр', 'Классический маникюр', 20.00, 30, NULL, NULL),
  ('Педикюр', 'Классический педикюр', 30.00, 45, NULL, NULL),
  ('Чистка лица', 'Глубокая чистка лица', 50.00, 60, NULL, NULL);

INSERT INTO public.workers (last_Name, first_Name, middle_Name, date_Of_Birth, gender, passport_Series, passport_id, passport_code, is_Active, pay_Coeff, speciality_id) VALUES
  ('Иванов', 'Иван', 'Иванович', '1985-03-10', 'Мужской', '4567', '123456', '789012', TRUE, 1.2, 1),
  ('Петрова', 'Анна', 'Сергеевна', '1990-07-25', 'Женский', '1234', '987654', '345678', TRUE, 1.0, 2),
  ('Сидоров', 'Алексей', 'Владимирович', '1988-11-15', 'Мужской', '9876', '543210', '123456', TRUE, 1.1, 3);

INSERT INTO public.time_Sheets (worker_id, service_id, service_Time, gender_Check) VALUES
  (1, 1, '10:00:00', TRUE),
  (2, 2, '11:30:00', TRUE),
  (3, 3, '14:00:00', TRUE),
  (1, 4, '16:30:00', TRUE),
  (2, 5, '18:00:00', TRUE);
 
 -- Вставка данных в таблицу public.client_Types
INSERT INTO public.client_Types (client_Type_name, color) VALUES
('Gold', 'Золотой'),
('Silver', 'Серебряный'),
('Bronze', 'Бронзовый'),
('Platinum', 'Платиновый'),
('Diamond', 'Алмазный'),
('Regular', 'Обычный'),
('VIP', 'VIP'),
('Premium', 'Премиум'),
('Exclusive', 'Эксклюзивный'),
('Elite', 'Элитный');

-- Вставка данных в таблицу public.clients
INSERT INTO public.clients (last_Name, first_Name, middle_Name, date_Of_Birth, gender, phone, email, photo, date_Of_Registration, client_Type_id) VALUES
('Смит', 'Иван', 'Иванович', '1985-03-15', 'Мужской', 89272422413, 'ivan.smith@example.com', 'https://example.com/ivan_smith_photo.jpg', '2023-01-10', 1),
('Джонсон', 'Анна', 'Петровна', '1990-07-22', 'Женский', 89424217538, 'anna.johnson@example.com', 'https://example.com/anna_johnson_photo.jpg', '2023-02-15', 2),
('Вильямс', 'Сергей', 'Васильевич', '1978-11-08', 'Мужской', 89457286464, 'sergey.williams@example.com', 'https://example.com/sergey_williams_photo.jpg', '2023-03-05', 3),
('Браун', 'Екатерина', 'Алексеевна', '1988-05-01', 'Женский', 89467364573, 'ekaterina.brown@example.com', 'https://example.com/ekaterina_brown_photo.jpg', '2023-04-20', 4),
('Джонс', 'Дмитрий', 'Юрьевич', '1992-09-12', 'Мужской', 89436579897, 'dmitry.jones@example.com', 'https://example.com/dmitry_jones_photo.jpg', '2023-05-10', 5),
('Дэвис', 'Ольга', 'Николаевна', '1986-12-28', 'Женский', 8999756324, 'olga.davis@example.com', 'https://example.com/olga_davis_photo.jpg', '2023-06-01', 6),
('Миллер', 'Василий', 'Петрович', '1975-02-18', 'Мужской', 8945653636, 'vasily.miller@example.com', 'https://example.com/vasily_miller_photo.jpg', '2023-07-15', 7),
('Уилсон', 'Татьяна', 'Ивановна', '1989-10-03', 'Женский', 89746326546, 'tatiana.wilson@example.com', 'https://example.com/tatiana_wilson_photo.jpg', '2023-08-05', 8),
('Мур', 'Алексей', 'Николаевич', '1982-06-25', 'Мужской', 89363646432, 'alexey.moore@example.com', 'https://example.com/alexey_moore_photo.jpg', '2023-09-20', 9),
('Тейлор', 'Светлана', 'Владимировна', '1993-01-17', 'Женский', 89362627534, 'svetlana.taylor@example.com', 'https://example.com/svetlana_taylor_photo.jpg', '2023-10-10', 10);

INSERT INTO public.visits (visit_id, client_id, time_Sheet_id, date_Regs, date_Actual, paid, rewiew, document) VALUES
  (1, 1, 1, '2023-04-10 10:00:00', '2023-04-10 10:45:00', TRUE, 'Все отлично!', NULL),
  (2, 2, 2, '2023-05-20 11:00:00', '2023-05-20 12:00:00', TRUE, 'Мастер очень вежливый', NULL),
  (3, 3, 3, '2023-06-15 14:00:00', '2023-06-15 14:30:00', TRUE, 'Рекомендую!', NULL),
  (4, 4, 4, '2023-07-05 16:00:00', '2023-07-05 17:00:00', TRUE, 'Все прошло хорошо', NULL),
  (5, 5, 5, '2023-08-10 17:30:00', '2023-08-10 18:30:00', TRUE, 'Отличный сервис!', NULL);

INSERT INTO public.sell_Visit (sell_id, visit_id) VALUES
  (1, 1),
  (2, 2),
  (3, 3),
  (4, 4),
  (5, 5);

INSERT INTO public.users (user_name, "password", role) VALUES
  ('admin', 'admin123', 'admin'),
  ('a', '1', 'manager'),
  ('user1', 'user123', 'user');


-- Вставка данных в таблицу public.shares
INSERT INTO public.shares (share_Name, share_Description) VALUES
('Facebook', 'Социальная сеть.'),
('Instagram', 'Фото и видео платформа.'),
('Twitter', 'Платформа для микроблогов.'),
('LinkedIn', 'Платформа для профессионального общения.'),
('YouTube', 'Платформа для обмена видео.'),
('Pinterest', 'Платформа для обмена изображениями и поиска.'),
('Reddit', 'Социальная сеть для новостей, рейтинга контента и обсуждений.'),
('TikTok', 'Приложение для обмена короткими видео.'),
('Snapchat', 'Приложение для обмена фото и видео с исчезающим контентом.'),
('Tumblr', 'Платформа для микроблогов и социальных сетей.');

-- Вставка данных в таблицу public.service_Shares
INSERT INTO public.service_Shares (share_id, service_id) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10);

-- Вставка данных в таблицу public.complects
INSERT INTO public.complects (main_Good_id, second_Good_id) VALUES
(1, 2),
(3, 4),
(5, 6),
(7, 8),
(9, 10),
(11, 12),
(13, 14),
(15, 16),
(17, 18),
(19, 20);

-- Вставка данных в таблицу public.stores
INSERT INTO public.stores (good_id, count) VALUES
(1, 10),
(2, 5),
(3, 15),
(4, 8),
(5, 20),
(6, 12),
(7, 7),
(8, 18),
(9, 9),
(10, 11);







